This section contains screenshots of simple-gpg project.
