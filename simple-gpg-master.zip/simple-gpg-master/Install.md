### Prerequisite : -

Git and Python 3 must be installed in the computer.

Run the following commands in Linux terminal / Windows powershell / command prompt to download.

```
git clone https://github.com/Anish-M-code/simple-gpg.git
```

```
cd simple-gpg/Source\ Code/
```

Then to get started : -

For Windows:

```
py simple_gpg.py
```

For Linux based Distributions:

```
python3 simple_gpg.py
```
