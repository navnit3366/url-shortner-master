This program requires no installation.
You can Execute this Python Program like any other Simple Python Program.

You can verify this software using my OPENPGP Key from here : https://outflaw.blogspot.com/2019/12/my-pgp-key.html

On windows after navigating to the directory where the program is present using command prompt following line is enough 
to start the program , you can even run using IDLE:-

```
py simple_gpg.py
```
On linux after navigating to the directory where the program is present using terminal following line is enough 
to start the program:-

```
python3 simple_gpg.py
```



