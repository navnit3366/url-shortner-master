# Chess-on-python
Check "SCREENSHOTS" to see how it works!

This is basically a chess made by python 3. I used pyglet library to make the graphical user interface for this project. This might not 
be the most efficient way to code chess with python, but I just wanted to learn programming through some project. That's what this is.
The game itself works just like any chess except for one thing. This one doesn't alert you when you are at check situation or even at 
checkmate. So if you get checkmate and you don't notice it and don't eat the king, the game just goes on. Only way to end the game is to
press "exit" button or actually eat opponent's king. Btw the "1 player" button at the menu doesn't work, because I haven't made NPC 
opponent yet.
