# python_projects

🧡🧡In this repository, I will provide some practice projects, Feel free to add any python projects you like and you have done and make a pull request🧡🧡

![ezgif-6-f8aad4de11bf](https://user-images.githubusercontent.com/68724228/89905849-442efa80-dc08-11ea-97fe-632c774e6b69.gif)

<p align="center"><i>©Gleb Kuznetsov</i></p>
