
# Simple-Calculator
Python tkinter gui application

![cal](https://user-images.githubusercontent.com/52861859/100331795-cd710e00-2ffa-11eb-86b3-d6704dc9dda9.PNG)

I used Python eval() Function which is Built-in Function.The eval() function evaluates the specified mathemetical expression
