
# Stop-Watch

**Install**

    pip install pillow

    pip install image
    
 ![stop watch](https://user-images.githubusercontent.com/52861859/100788623-89896900-343f-11eb-9cee-48e1d3076041.PNG)
