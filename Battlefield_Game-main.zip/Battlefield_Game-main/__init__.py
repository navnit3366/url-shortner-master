"""
Main. 

Main module executes the game.
Elements package contains all data, interactive, and helper elements for the\
    game
"""

__all__ = ["Main", "Elements"]