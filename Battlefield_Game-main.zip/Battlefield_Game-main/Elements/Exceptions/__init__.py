"""
Exceptions Package: for custom exceptions.

InputException module contains input-related exceptions.
"""

__all__ = ["InputExceptions"]