Socio-Network !

This is a WebApp(Side project) made by me to explore Django framework and practice it. The project aims at developing a Social Network webapp having basic authentication and features such as user creation, adding or removing friends, viewing their profile etc. Features provided in the webApp are as follows:

1. Create/Register a new user
2. Login for a registered user
3. Upload a profile picture
4. Reset your password via email.
5. View other people registered on the webApp.
6. Add or remove Friends from your profile.( currently under development ).

For further changes, contact the author of the project at "itsme.rishabhk@gmail.com" before committing into the master.


NOTE: For any future commits to the repository, please do not contribute to the master directly, instead make contributions to the CONTRIBUTION branch and create a pull request so that the author/authors can review your changes and merge them manually to the master if no clashes were encountered. Having contributing to the master directly can lead to banning of your account from using this project.
