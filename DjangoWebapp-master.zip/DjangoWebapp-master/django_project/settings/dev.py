from django_project.settings.base import *

DEBUG = False