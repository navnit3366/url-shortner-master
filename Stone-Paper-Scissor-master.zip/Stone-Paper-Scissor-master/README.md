# Stone-Paper-Scissor
The popular game Stone Paper Scissor implemented as a desktop app using Pygame Module of Python.
Player vs. Computer is added with immersive sounds.

### Gameplay
![Farmers Market Finder Demo](Demo/Demo.gif)

### Issues/Future Upgrades
Add restart button at end of each game.
