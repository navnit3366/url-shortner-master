# Learn programming with Python
This is a repository that contains solutions for tasks from book [Learn programming: from zero to first program with Python](https://www.qavsdev.com/programming-from-zero/). You can get the book for free on the previous link.

![book-cover](https://github.com/qavsdev/learn-programming-with-python/blob/main/book-cover.png)
