A = input('Please enter the first number: ')
B = input('Please enter the second number: ')

SUM = int(A) + int(B)
print(SUM)
