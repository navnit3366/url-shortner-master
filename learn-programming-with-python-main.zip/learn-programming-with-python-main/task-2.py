A = input('Please enter a number: ')

if int(A) < 0:
  print("Negative")
else:
  print("Positive")
