A = input('Please input the first number: ')
B = input('Please input the second number: ')

SUM = int(A) + int(B)

if SUM > 50:
  print("BIGGER")
else:
  print("SMALLER")
