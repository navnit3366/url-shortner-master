counter = 0

while counter < 11:
  print(counter)
  counter += 1
