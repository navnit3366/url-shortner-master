counter = 100

while counter > 0:
  print(counter)
  counter -= 1
