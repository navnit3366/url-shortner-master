# QRCodeGenerator-Python

This is a Python Program to create a QR Code for any URL.

## How to Clone this Repository

To clone this repository, paste the following command in your terminal:

git clone https://github.com/MadeWithAI/QRCodeGenerator-Python.git
