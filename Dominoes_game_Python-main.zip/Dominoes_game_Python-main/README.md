# Dominoes Game
- I tried to create a game which is called dominoes. It was a fun process and I learnt a lot of things about loops, functions, random & re module, dictionaries, buit-in functions like enumerate(), etc. It is based on basic python knowledge but requires lots of brainstorming to achieve the results.
- The game is played between the computer and the player. Yes, I also coded an AI algorithm so that computer makes automatic and intelligent moves. This is the main feature of this project - the AI.
- Some important features:-
  - It is based on AI which means that the game is between the computer and a human. The computer makes automatic and intelligent moves.
  - It prompts the human player for any invalid input and keeps asking input till valid one is recieved.
  - It checks winning and draw conditions after every move and stops the game if conditions are met, otherwise the game continues.
