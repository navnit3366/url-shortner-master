Simple Student Management System project is written in Python. The project file contains a python script (student.py). This is a simple console based system which is very easy to understand and use. Talking about the system, it contains basic functions which include Add students, view students, search students and remove the student. In this mini project, there is no such login system. This means he/she can use all those available features easily without any restriction. It is too easy to use, he/she can check the total student’s record.

While adding the students, the user only has to enter his/her name then the system adds the record and displays to the user. And the user can view all these students lists from the view section. In this Simple Student Management, the user can also search for student’s name in order to know whether the student’s record exists in the system or not. This simple console based Student Management system provides the simplest management of student’s list. In short, this projects mainly focus on CRUD. There is no database connection or neither any external text or other files used in this mini project to save user’s data permanently.

In order to run the project, you must have installed Python, on your PC. This is a simple Console Based system, specially written for the beginners. Simple Student Management System in Python project with source code is free to download. Use for education purpose only! For the project demo, have a look at the YouTube Video Above.

Features:
Add Students
List all students
Search students
Remove Students
How To Run :
first you need install python.
download project.
extract project.
double click in student.py.
Project is run
Thanks ....
