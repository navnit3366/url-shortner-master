
num = int(input())
if num %2 == 0:
    print('prime')
else:
    print('not prime')
    

