# simple code for beginners developers
i hope use this repositroy ,good luck:)

## use multiple programming languagus 
- python
- javascript
- html/css
- the more languagus at soon 

