# Banque

A simple python code to understand Blockchain 
