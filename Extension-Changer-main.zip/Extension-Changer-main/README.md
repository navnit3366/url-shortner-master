# Extension-Changer
A simple application that will help you to change the extension of files in a folder to a specific extension, inorder to hide secret files from other intruders, as an initial level of security.
# under development
