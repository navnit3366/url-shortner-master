This is program for a coffee machine that offers espresso, latte and cappuccino in its menu. 

The data.py file stores all the information on available hot beverages and the available resources in dictionaries. main.py holds all the logic in working of the machine.

Anyone who recently started learning python is welcome to contribute and help develop the program further. 

Currently working on handling user input errors and storing data into a file to be read when machine is restarted

Feel free to fork the repo do your own thing with it


