# Cartoonifying Image Uisng OpenCV

This is a simple Python program to cartoonify the sample image using a computer vision library called openCV.

![Python](https://img.shields.io/badge/-python-brightgreen)
![openCV](https://img.shields.io/badge/openCV-8338ec)
![Beginner Project](https://img.shields.io/badge/beginner%20project-3a86ff)

# Get the code

```shell
git clone https://github.com/Sachin-crypto/Cartoonify-Image-Using-OpenCV.git
```

**OR**

Download the code as [zip](https://github.com/Sachin-crypto/Cartoonify-Image-Using-OpenCV/archive/refs/heads/main.zip) file.

**Feel free to report an issue and add more functionality.**
