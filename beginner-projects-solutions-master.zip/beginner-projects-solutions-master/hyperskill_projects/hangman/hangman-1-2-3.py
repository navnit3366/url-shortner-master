print("H A N G M A N")
print("The game will be available soon.")
secret_word = "python"
guess = input("Guess the word: ")
if guess == secret_word:
    print("You survived!")
else:
    print("You lost!")