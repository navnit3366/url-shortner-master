

# def guest_fname():
#     guest_first=(str.capitalize(input('guest first name?  ')))
#     return guest_first
# print(guest_fname())


# None==str.capitalize('none')
# None is None
a=[4,6,7,8]
b=[12,3,2,9]
c=[]

for i in a:
    for j in b:
        print (i*j)

#passing thought, or something like this...
# for i in a and j in b:
#     print(i*j)
