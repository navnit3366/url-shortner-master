# SheetSQL
Google Sheets as an SQL Database | In Progress

## Getting Started
**Coming Soon**

## Examples

**Coming Soon**

## Changes From Standard SQL
```sql
CREATE TABLE table_name(col1 datatype,) ==> 
CREATE TABLE table_name(col1, col2)
```
No longer accepts datatypes when creating a table. Can store `Numbers`, `Strings`, `Boolean Values`, `Datetime Objects`, `Lists`