# Flames using python 
- FLAME is a game named after the acronym: Friends, Lovers, Affectionate, Marriage, Enemies. ... This game does not accurately predict whether or not an individual is right for you, but it can be fun to play this with your friends.

# usage 
- Enter your name (caseinsensitive)
- Enter another persons name (caseinsensitive)
- Just enter main name no initials or surnames are needed !!!

![ji](https://user-images.githubusercontent.com/72141859/132999438-6d1d5a9d-08bf-4649-b316-46770ec9130f.png)


