# Minna No Python: Mini Python Projects for Beginners
Example Projects which solve Real world problems. Intended for beginners/intermediate users to learn Python. These are projects that you can run on any interpreters small or large without installing any fancy third-party plugins.

Written by Alexander Laurence.

Licensed under MIT
