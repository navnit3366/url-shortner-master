# Space-Invaders
[Under development] A simple game I made to learn python

*NOTE: You need to have pygame installed in order to play this game.*

To play the game, run spaceInvaders.py. Use the arrow keys to move the ship, space key to fire at aliens, and finally q to quit. Enjoy :)

This game is based upon a pygame tutorial found in a book called "Python crash course".

TO DO list:

  1. ~~Add a scoring system.~~

  2. ~~Add a "play again" button.~~

  3. ~~Add some sort of health/lives indicator.~~

  4. ~~Add a starting screen(some sort of intro and a splash screen).~~ **A play button has been added**
  
  5. ~~Allow aliens to shoot the ship.~~

  6. Add shelters for the ship.

  7. Improve the game's overall look and feel.
