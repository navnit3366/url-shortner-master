#prompts for a series of input
programmer = input("Someones Name: ")
company = input("A Company Name: ")
language1 = input("A Programming Language: ")
recruiter = input("Someone else's Name: ")
language2 = input("Another Programmin Language: ")

#printing the story with the given inputs
print("--------------------------------------------------------------------")
print(programmer + " went to attend an interview at " + company + " for the first time.")
print("He knows well to code in " + language1 +".")
print(recruiter + ', the HR says that "we need a ' + language2 + ' developer, so You can go home".')
