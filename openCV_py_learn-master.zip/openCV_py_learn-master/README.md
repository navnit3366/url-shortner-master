# openCV_py_learn
collection of all example and all test i made in python using openCV just for waste time

in the directory "try basic function" some file need a foto please corect that error if you find

# required libraries

* ### cv2
* ### numpy
* ### matplotlib
