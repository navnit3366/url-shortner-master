# sudoku
This is a simple 4x4 Sudoku game I created in Python for my class. 
