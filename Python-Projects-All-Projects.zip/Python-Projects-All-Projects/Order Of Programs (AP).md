# Advanced Projects:

| Serial No. | Program Name |
|------------|--------------|
|1           | [ContentAggregator.py](https://github.com/psavarmattas/Python-Projects/blob/master/ContentAggregator.py) |
|2           | [PlagiarismChecker.py](https://github.com/psavarmattas/Python-Projects/blob/master/PlagiarismChecker.py) |
