limit = 10
for i in range(limit):
    print(i)
