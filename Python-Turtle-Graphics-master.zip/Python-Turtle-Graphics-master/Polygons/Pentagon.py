from turtle import *

for i in range(5):
    fd(100)
    rt(72)
