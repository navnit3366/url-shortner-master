from turtle import *

for i in range(10):
    fd(100)
    rt(36)
