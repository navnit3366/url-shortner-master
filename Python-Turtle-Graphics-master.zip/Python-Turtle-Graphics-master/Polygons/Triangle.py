from turtle import *

for i in range(3):
    fd(100)
    rt(120)
