from turtle import *

for i in range(12):
    fd(100)
    rt(30)
