from turtle import *

for i in range(2):
    fd(200)
    rt(90)
    fd(100)
    rt(90)
