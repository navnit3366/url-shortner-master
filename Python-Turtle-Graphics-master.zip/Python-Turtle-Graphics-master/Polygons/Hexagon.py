from turtle import *

for i in range(6):
    fd(100)
    rt(60)
