from turtle import *

for i in range(4):
    fd(100)
    rt(90)
