from turtle import *

for i in range(8):
    fd(100)
    rt(45)
