from turtle import *

for i in range(7):
    fd(100)
    rt(360/7)
