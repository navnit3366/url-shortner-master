from turtle import *

for i in range(9):
    fd(100)
    rt(40)
