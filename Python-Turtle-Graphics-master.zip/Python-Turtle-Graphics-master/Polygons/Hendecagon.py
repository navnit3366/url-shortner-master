from turtle import *

for i in range(11):
    fd(100)
    rt(360/11)
