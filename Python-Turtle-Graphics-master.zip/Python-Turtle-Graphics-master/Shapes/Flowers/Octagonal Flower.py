from turtle import *
pensize(5)
for i in range(8):
    for i in range(8):
        rt(45)
        fd(100)
    rt(45)
ht()
