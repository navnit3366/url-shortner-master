from turtle import *
pensize(5)
for i in range(8):
    for i in range(5):
        rt(72)
        fd(200)
    rt(45)
ht()
