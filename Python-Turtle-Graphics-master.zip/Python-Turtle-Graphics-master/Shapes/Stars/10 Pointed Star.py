from turtle import *

for i in range(10):
    fd(200)
    rt(108)
