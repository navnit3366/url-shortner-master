from turtle import *

for i in range(5):
    fd(200)
    rt(144)
