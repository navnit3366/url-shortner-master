from turtle import *

for i in range(8):
    fd(200)
    rt(135)
