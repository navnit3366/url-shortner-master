from turtle import *

lt(90)
fd(200)
rt(90)
fd(50)
bk(100)
ht()
