import turtle

t = turtle.Turtle()

t.right(90)
t.forward(50)
for i in range(75):
  t.right(2)
  t.forward(1)
