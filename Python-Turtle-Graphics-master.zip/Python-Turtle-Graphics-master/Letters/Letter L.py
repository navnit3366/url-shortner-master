from turtle import *

rt(90)
fd(100)
lt(90)
fd(75)

