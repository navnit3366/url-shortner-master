from turtle import *

lt(125)
fd(200)
bk(200)
rt(70)
fd(200)
ht()
