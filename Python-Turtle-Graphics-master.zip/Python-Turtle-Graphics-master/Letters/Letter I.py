import turtle

t = turtle.Turtle()

t.forward(50)
t.backward(25)
t.left(90)
t.forward(75)
t.right(90)
t.forward(25)
t.backward(50)
