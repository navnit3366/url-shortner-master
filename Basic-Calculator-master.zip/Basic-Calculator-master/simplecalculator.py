from Variables.variables import *
from Functions.functions import *
from Functions.window import *

window.mainloop()  # Loops window to remain running