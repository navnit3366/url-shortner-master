# BasicCalculator

## Description:
This calculator has a fully interactable GUI using Python's Tkinter module. It is a basic calculator with only a few basic operations.

![Screenshot](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/woeq7lyehdfcxqjhoocl.png)

## How to use:
- Click on desired button with left mouse button

## Creator:
[GitHub](https://github.com/shiahalan)

## License:
This project is under the Apache 2.0 License
