This is a n variable equation solver

First enter no. of variables (n)(max 50)
Then  enter n equations

You will get the solution for all variable 

                            Caution::
        This program will run only if you enter int coefficients only and
        single charachter variables 'variable name cant be a no.'
        All the variables should be on LHS and RHS should be only
        positive integer constant.



  Eg. of inputing eqns    
    
    Incorrect ways     
         1. y-x=-2
         2. y=x-2
         3. 0.5x-0.5y=1

      Correct way
          x-y=2

To run on windows
  
  Download and run exe file


To run on linux
  
  1.Downloag bash file
  
  2.Open Download folder in terminal and type foll commands
          
          chmod 777 eqnsolver-linux-bash-file
          ./eqnsolver-linux-bash-file
         

Thank you for viewing 

For any issues/suggestions
Contact : gurkiratsingh2001@gmail.com



 
