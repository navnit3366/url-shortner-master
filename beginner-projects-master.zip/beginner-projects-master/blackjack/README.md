This is a blackjack game in python 

It has limited features for now but soon i will be adding more

Till now it only has hit/stay options 

You will play against computer

Thanks for viewing suggestions are welcomed 

Contact gurkiratsingh2001@gmail.com
