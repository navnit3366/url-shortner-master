﻿
RIVER CROSSING GAME 

Written in python3

 --General Keys-- 
Press 'Esc' to quit the game at any time. 
Press 'Space' to pause/unpause the game. 

--Obstacles-- 
There are 3 types of obstacles: 
1. Big ship	: Moving
2. Small ship 	: moving
2. Crabs 	: Static 
 
--Gameplay-- 
There are 2 players in the game
The 2 players will compete in different worlds.
Each player will have 30 seconds to complete it’s world , else he will die !.
On crashing with crab or any ship, the player with die.
The player who will complete the track and has higher score will be the winner
The speed of ships will increase for the winner in next world
Speed of ships will be shown in the scorebar at all times.
At end of each world, results would be shown for that world.
As the world increase , number of crabs will increase


--Controls-- 
Both the players can move in any direction with arrow keys. 
 

--Scoring-- 
At start of each world both players will get 30 base points
Each second the current player score will decrease by 1.
Score will increase by 10 on crossing a big/small ship. 
Score will increase by 5 on crossing a monster.
On crashing with any ship,  current player score will decrease by 5
On crashing with  any crab, current player score wil decrease ny 10 

 
--Ending Game-- 
Actually its a never ending game. 
You can play as long a you want.
Press ESC to quit


HAVE FUN !! 


created by - Gurkirat Singh
Roll no:- 2019101069
contact:- gurkirat.singh@students.iiit.ac.in 
	  gurkiratsingh2001@gmail.com
