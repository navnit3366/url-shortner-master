This is a program which will solve a 4-variable kmap

To run on windows 

    1. Download the exe file
    
    2. Run exe file by clicking on it.


To run on on linux 

    1.Download bash executable file
    
    2.open Downloads folder in terminal
    
    3.Type following in terminal
    
       i) chmod 777 kmap-linux-bash-file
       ii) ./kmap-linux-bash-file
 
Thanks for viewing

Suggestions are welcome
at gurkiratsingh2001@gmail.com

