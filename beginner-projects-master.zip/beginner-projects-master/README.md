Hi ,Gurkirat Singh here
I am currently in 1st year at IIIT Hyderabad pursuing my BTech. in Computer Science

I love to create projects

Here i will keep posting my all projects.

TilL now i have created the following
  
  1.A n-variable equation solver in c++.
  
  2.A K-Map solver in c++
  
  3.A blackjack card game in python
    
  4.A small river crossing game
 
 Thank you for seeing my projects
 I want more ideas and suggestions on my existing projects or new projects.
 You can contact me through my email gurkiratsingh2001@gmail.com

 Cheers..
 



