import pyttsx3
from pyttsx3 import engine
friend = pyttsx3.init()
friend.say("You are dashingly smart!")
friend.runawait()
engine.init
