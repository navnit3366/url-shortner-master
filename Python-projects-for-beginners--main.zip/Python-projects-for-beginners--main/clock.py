import time

while True:
    current_time = time.strftime("%I:%M:%S %p")
    print(current_time)
    time.sleep(1)
