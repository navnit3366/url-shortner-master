# Restaurant_Billing_sys

Prints your bill on all the food u have ordered 

It's a basic project made up by using python as the programing language and mysql as the database to it 

this project can be used to understand how connection of mysql and python happens and how it works 


